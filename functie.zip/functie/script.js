let Arowbey = {Genre: "Hip/Rap", afkomst:"Congolees",hobbys:"sporten" };

let Booba = {Genre: "Hip/Rap", afkomst:"Senegalees",hobbys:"sporten" };

let Ninho = {Genre: "Hip/Rap", afkomst:"Congolees",hobbys:"Gamen" };
let lijstrappers = [Arowbey, Booba, Ninho];

for (let i = 0; i < 5; i++) {
    console.log(i);
}
console.log(lijstrappers.length)

for (let i = 0; i < lijstrappers.length; i++) {
    console.log(lijstrappers[i]);
}