var Arowbey = {Genre: "Hip/Rap", afkomst:"Congolees",hobbys:"sporten" };

var Booba = {Genre: "Hip/Rap", afkomst:"Senegalees",hobbys:"sporten" };

var Ninho = {Genre: "Hip/Rap", afkomst:"Congolees",hobbys:"Gamen" };

var lijstrappers = [Arowbey, Booba, Ninho];
for (let rappers of lijstrappers) {
    console.log(rappers);
}